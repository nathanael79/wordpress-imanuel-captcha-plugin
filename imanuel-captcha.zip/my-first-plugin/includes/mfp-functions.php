<?php
include_once 'captcha.php';
/*
You can use these hooks as well to place your fields
login_form_bottom - login_form_top - login_form_middle
*/

add_action('login_form','my_added_login_field');
function my_added_login_field(){
    ?>
    <img src="<?php echo plugins_url( '/tmp/image/captcha.png', __FILE__ );?>">
    <div>
        Can't read the image? Click
        <a href='<?php echo $_SERVER['PHP_SELF']; ?>'>
            here
        </a>
        to refresh!
    </div>
    <input type="text" value="" class="input" id="my_extra_field" name="my_extra_field_name"/>
    <?php
}


//function check_captcha($user)
//{
//    $captchaInput = $_POST['my_extra_field_name'];
//
//    if($captchaInput != $_SESSION['captcha_string'])
//    {
//        remove_action('authenticate', 'wp_authenticate_username_password', 20);
//        return new WP_Error( 'denied', __("<strong>ERROR</strong>: Captcha Doesnt Match (".$captchaInput." ".$_SESSION['captcha_string'].") ") );
//    }else{
//        return $user;
//    }
//
//}
//
//add_filter( 'wp_authenticate_user', 'check_captcha', 10, 2 );



