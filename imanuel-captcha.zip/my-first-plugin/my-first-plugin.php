<?php
/*
Plugin Name: Imanuel Captcha
Description: This is my first plugin! It generate Captcha in login page
Author: Imanuel Ronaldo
*/

// Include mfp-functions.php, use require_once to stop the script if mfp-functions.php is not found
require_once plugin_dir_path(__FILE__) . 'includes/mfp-functions.php';